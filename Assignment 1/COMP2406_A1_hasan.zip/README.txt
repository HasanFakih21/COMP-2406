Hasan Fakih	101168868

images folder
js folder -> comm-fridge-data.js, community=fridge.ks
community-fridge.css
index.html
fridge.html

Instructions:
open index.html on browser